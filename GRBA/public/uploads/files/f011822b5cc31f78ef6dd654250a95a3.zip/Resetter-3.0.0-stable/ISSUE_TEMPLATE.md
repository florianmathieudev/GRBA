*Issue title

*Linux Distro and version

*Version of Resetter

*Description of Issue

*Content of log file located in /var/log/resetter/resetter.log if applicable
